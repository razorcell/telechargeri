<?php

/**
 *
 *
 * @version $Id$
 * @copyright 2011
 */


$var_dump($params);
echo 'testscript';

?>