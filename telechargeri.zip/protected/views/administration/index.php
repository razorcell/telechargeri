

<?php
/* @var $this AdministrationController */
/*
 $this->breadcrumbs=array(
 		'Administration',
 );*/
?>
<h1>
	<?php echo $this->id . '/' . $this->action->id; ?>
</h1>
HOME PAGE
<?php echo $string;?>



